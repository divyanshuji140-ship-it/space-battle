import pygame
import random

pygame.init()

# =========================
# SCREEN
# =========================
WIDTH = 480
HEIGHT = 800

screen = pygame.display.set_mode(
    (WIDTH, HEIGHT),
    pygame.FULLSCREEN | pygame.SCALED
)
pygame.display.set_caption("SPACE BATTLE")

clock = pygame.time.Clock()

# =========================
# COLORS
# =========================
WHITE = (255, 255, 255)
BLUE = (30, 190, 255)
RED = (255, 60, 60)
GREEN = (50, 255, 100)
YELLOW = (255, 220, 50)
PURPLE = (180, 50, 255)
DARK = (5, 8, 30)

# =========================
# FONTS
# =========================
font = pygame.font.Font(None, 36)
big_font = pygame.font.Font(None, 70)

# =========================
# PLAYER
# =========================
player = pygame.Rect(210, 580, 60, 70)

player_speed = 6
lives = 3

# =========================
# BULLETS
# =========================
player_bullets = []
enemy_bullets = []

bullet_speed = 10
shoot_cooldown = 0

# =========================
# ENEMIES
# =========================
enemies = []

enemy_speed = 2


def create_enemies():
    enemies.clear()

    for i in range(5):
        enemies.append(
            pygame.Rect(
                random.randint(20, WIDTH - 70),
                random.randint(-300, 200),
                50,
                45
            )
        )


create_enemies()

# =========================
# SCORE
# =========================
score = 0
player_name = "Ronak"

# =========================
# BOSS
# =========================
boss = pygame.Rect(150, 80, 180, 100)

boss_hp = 300
boss_max_hp = 300

boss_speed = 3
boss_direction = 1

boss_shoot_timer = 0

# Boss active when score reaches 100
boss_active = False

# =========================
# STARS
# =========================
stars = []

for i in range(100):
    stars.append([
        random.randint(0, WIDTH),
        random.randint(0, HEIGHT),
        random.randint(1, 3)
    ])

# =========================
# DRAW PLAYER
# =========================
def draw_player():

    x = player.x
    y = player.y

    # Ship body
    points = [
        (x + 30, y),
        (x + 5, y + 60),
        (x + 30, y + 48),
        (x + 55, y + 60)
    ]

    pygame.draw.polygon(screen, BLUE, points)

    # Cockpit
    pygame.draw.circle(
        screen,
        WHITE,
        (x + 30, y + 25),
        8
    )

    # Engine
    pygame.draw.polygon(
        screen,
        RED,
        [
            (x + 20, y + 55),
            (x + 30, y + 72),
            (x + 40, y + 55)
        ]
    )


# =========================
# DRAW ENEMY
# =========================
def draw_enemy(enemy):

    pygame.draw.rect(
        screen,
        RED,
        enemy
    )

    pygame.draw.circle(
        screen,
        GREEN,
        enemy.center,
        8
    )


# =========================
# DRAW BOSS
# =========================
def draw_boss():

    pygame.draw.rect(
        screen,
        PURPLE,
        boss
    )

    # Boss core
    pygame.draw.circle(
        screen,
        GREEN,
        boss.center,
        25
    )

    # Eyes
    pygame.draw.circle(
        screen,
        RED,
        (boss.x + 50, boss.y + 35),
        10
    )

    pygame.draw.circle(
        screen,
        RED,
        (boss.x + 130, boss.y + 35),
        10
    )


# =========================
# BUTTON
# =========================
def draw_button(rect, text):

    pygame.draw.rect(
        screen,
        (20, 60, 110),
        rect
    )

    pygame.draw.rect(
        screen,
        BLUE,
        rect,
        3
    )

    text_img = font.render(
        text,
        True,
        WHITE
    )

    screen.blit(
        text_img,
        (
            rect.centerx - text_img.get_width() // 2,
            rect.centery - text_img.get_height() // 2
        )
    )


# =========================
# TOUCH BUTTONS
# SAME SIZE AS BEFORE
# =========================

left = pygame.Rect(20, 700, 90, 60)
right = pygame.Rect(120, 700, 90, 60)

up = pygame.Rect(70, 630, 90, 60)

down = pygame.Rect(70, 770, 90, 25)

shoot = pygame.Rect(320, 690, 130, 80)


# =========================
# RESET GAME
# =========================
def reset_game():

    global lives
    global score
    global boss_hp
    global boss_active
    global boss_shoot_timer
    global shoot_cooldown
    global boss_direction

    # Player
    player.x = 210
    player.y = 580

    # Game stats
    lives = 3
    score = 0

    # Boss
    boss_hp = boss_max_hp
    boss_active = False

    boss.x = 150
    boss.y = 80

    boss_direction = 1
    boss_shoot_timer = 0

    # Shooting
    shoot_cooldown = 0

    # Clear bullets
    player_bullets.clear()
    enemy_bullets.clear()

    # Recreate enemies
    create_enemies()


# =========================
# GAME STATE
# =========================
game_state = "playing"

running = True


# =========================
# MAIN GAME LOOP
# =========================
while running:

    mouse_pressed = pygame.mouse.get_pressed()[0]

    mouse_x, mouse_y = pygame.mouse.get_pos()

    # =====================
    # EVENTS
    # =====================
    for event in pygame.event.get():

        # Quit
        if event.type == pygame.QUIT:
            running = False

        # =================
        # TAP ANYWHERE
        # TO RESTART
        # =================
        if event.type == pygame.MOUSEBUTTONDOWN:

            if game_state == "gameover":

                reset_game()
                game_state = "playing"

            elif game_state == "win":

                reset_game()
                game_state = "playing"

        # =================
        # ANDROID TOUCH
        # =================
        if event.type == pygame.FINGERDOWN:

            if game_state == "gameover":

                reset_game()
                game_state = "playing"

            elif game_state == "win":

                reset_game()
                game_state = "playing"


    # =========================
    # PLAYING
    # =========================
    if game_state == "playing":

        # =====================
        # TOUCH CONTROLS
        # =====================
        if mouse_pressed:

            # LEFT
            if left.collidepoint(mouse_x, mouse_y):
                player.x -= player_speed

            # RIGHT
            if right.collidepoint(mouse_x, mouse_y):
                player.x += player_speed

            # UP
            if up.collidepoint(mouse_x, mouse_y):
                player.y -= player_speed

            # DOWN
            if down.collidepoint(mouse_x, mouse_y):
                player.y += player_speed

            # SHOOT
            if shoot.collidepoint(mouse_x, mouse_y):

                if shoot_cooldown <= 0:

                    player_bullets.append(
                        pygame.Rect(
                            player.centerx - 4,
                            player.y,
                            8,
                            20
                        )
                    )

                    shoot_cooldown = 10


        # =====================
        # KEYBOARD CONTROLS
        # =====================
        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT]:
            player.x -= player_speed

        if keys[pygame.K_RIGHT]:
            player.x += player_speed

        if keys[pygame.K_UP]:
            player.y -= player_speed

        if keys[pygame.K_DOWN]:
            player.y += player_speed


        # =====================
        # KEEP PLAYER ON SCREEN
        # =====================
        player.x = max(
            0,
            min(WIDTH - player.width, player.x)
        )

        player.y = max(
            0,
            min(HEIGHT - 150, player.y)
        )


        # =====================
        # SHOOT COOLDOWN
        # =====================
        if shoot_cooldown > 0:
            shoot_cooldown -= 1


        # =====================
        # BOSS ACTIVATION
        # =====================
        if score >= 100:

            boss_active = True

            enemies.clear()


        # =====================
        # NORMAL ENEMIES
        # =====================
        if not boss_active:

            for enemy in enemies:

                enemy.y += enemy_speed

                # Enemy goes back to top
                if enemy.y > HEIGHT:

                    enemy.y = random.randint(
                        -200,
                        -50
                    )

                    enemy.x = random.randint(
                        20,
                        WIDTH - 70
                    )


                # Enemy hits player
                if player.colliderect(enemy):

                    lives -= 1

                    enemy.y = -100

                    enemy.x = random.randint(
                        20,
                        WIDTH - 70
                    )

                    if lives <= 0:

                        game_state = "gameover"


        # =====================
        # BOSS
        # =====================
        if boss_active:

            # Boss movement
            boss.x += (
                boss_speed *
                boss_direction
            )

            if boss.x <= 0:

                boss_direction = 1

            if boss.x + boss.width >= WIDTH:

                boss_direction = -1


            # =================
            # BOSS FIRE
            # 150 FRAMES
            # = 2.5 SECONDS
            # =================
            boss_shoot_timer += 1

            if boss_shoot_timer >= 150:

                boss_shoot_timer = 0

                # Three bullets
                enemy_bullets.append(
                    pygame.Rect(
                        boss.centerx - 5,
                        boss.bottom,
                        10,
                        25
                    )
                )

                enemy_bullets.append(
                    pygame.Rect(
                        boss.centerx - 60,
                        boss.bottom,
                        10,
                        25
                    )
                )

                enemy_bullets.append(
                    pygame.Rect(
                        boss.centerx + 50,
                        boss.bottom,
                        10,
                        25
                    )
                )


        # =====================
        # PLAYER BULLETS
        # =====================
        for bullet in player_bullets[:]:

            bullet.y -= bullet_speed

            # Bullet leaves screen
            if bullet.y < 0:

                player_bullets.remove(bullet)

                continue


            # =================
            # HIT NORMAL ENEMY
            # =================
            for enemy in enemies[:]:

                if bullet.colliderect(enemy):

                    if bullet in player_bullets:
                        player_bullets.remove(bullet)

                    enemies.remove(enemy)

                    score += 10

                    # New enemy
                    enemies.append(
                        pygame.Rect(
                            random.randint(
                                20,
                                WIDTH - 70
                            ),
                            random.randint(
                                -300,
                                -50
                            ),
                            50,
                            45
                        )
                    )

                    break


            # =================
            # HIT BOSS
            # =================
            if boss_active:

                if bullet.colliderect(boss):

                    if bullet in player_bullets:
                        player_bullets.remove(bullet)

                    # Damage
                    boss_hp -= 5

                    # Boss defeated
                    if boss_hp <= 0:

                        boss_hp = 0

                        game_state = "win"


        # =====================
        # ENEMY BULLETS
        # =====================
        for bullet in enemy_bullets[:]:

            bullet.y += 7

            # Bullet leaves screen
            if bullet.y > HEIGHT:

                enemy_bullets.remove(bullet)

                continue


            # Hit player
            if bullet.colliderect(player):

                enemy_bullets.remove(bullet)

                lives -= 1

                if lives <= 0:

                    game_state = "gameover"


    # =========================
    # DRAW BACKGROUND
    # =========================
    screen.fill(DARK)


    # =========================
    # STARS
    # =========================
    for star in stars:

        pygame.draw.circle(
            screen,
            WHITE,
            (star[0], star[1]),
            star[2]
        )

        star[1] += 1

        if star[1] > HEIGHT:

            star[1] = 0


    # =========================
    # PLAYER NAME
    # =========================
    name_text = font.render(
        "Player: " + player_name,
        True,
        WHITE
    )
    screen.blit(name_text, (20, 55))

    # =========================
    # SCORE
    # =========================
    score_text = font.render(
        "Score: " + str(score),
        True,
        WHITE
    )

    screen.blit(
        score_text,
        (20, 20)
    )


    # =========================
    # LIVES
    # =========================
    lives_text = font.render(
        "Lives: " + str(lives),
        True,
        WHITE
    )

    screen.blit(
        lives_text,
        (330, 20)
    )


    # =========================
    # PLAYING SCREEN
    # =========================
    if game_state == "playing":

        # Player
        draw_player()


        # Enemies
        for enemy in enemies:

            draw_enemy(enemy)


        # =====================
        # BOSS DISPLAY
        # =====================
        if boss_active:

            draw_boss()

            # Boss HP background
            pygame.draw.rect(
                screen,
                RED,
                (70, 190, 340, 20)
            )

            # Boss HP
            hp_width = int(
                340 *
                boss_hp /
                boss_max_hp
            )

            pygame.draw.rect(
                screen,
                GREEN,
                (70, 190, hp_width, 20)
            )

            boss_text = font.render(
                "BOSS",
                True,
                WHITE
            )

            screen.blit(
                boss_text,
                (210, 215)
            )


        # =====================
        # PLAYER BULLETS
        # =====================
        for bullet in player_bullets:

            pygame.draw.rect(
                screen,
                BLUE,
                bullet
            )


        # =====================
        # ENEMY BULLETS
        # =====================
        for bullet in enemy_bullets:

            pygame.draw.rect(
                screen,
                RED,
                bullet
            )


        # =====================
        # TOUCH BUTTONS
        # =====================
        draw_button(
            left,
            "◀"
        )

        draw_button(
            right,
            "▶"
        )

        draw_button(
            up,
            "▲"
        )

        draw_button(
            down,
            "▼"
        )

        draw_button(
            shoot,
            "SHOOT"
        )


    # =========================
    # GAME OVER
    # =========================
    if game_state == "gameover":

        text = big_font.render(
            "GAME OVER",
            True,
            RED
        )

        screen.blit(
            text,
            (
                WIDTH // 2 -
                text.get_width() // 2,
                300
            )
        )

        restart_text = font.render(
            "Tap anywhere to restart",
            True,
            WHITE
        )

        screen.blit(
            restart_text,
            (
                WIDTH // 2 -
                restart_text.get_width() // 2,
                390
            )
        )


    # =========================
    # WIN
    # =========================
    if game_state == "win":

        text = big_font.render(
            "YOU WIN!",
            True,
            GREEN
        )

        screen.blit(
            text,
            (
                WIDTH // 2 -
                text.get_width() // 2,
                300
            )
        )

        boss_defeated = font.render(
            "BOSS DEFEATED!",
            True,
            WHITE
        )

        screen.blit(
            boss_defeated,
            (
                WIDTH // 2 -
                boss_defeated.get_width() // 2,
                380
            )
        )

        again_text = font.render(
            "Tap anywhere to play again",
            True,
            WHITE
        )

        screen.blit(
            again_text,
            (
                WIDTH // 2 -
                again_text.get_width() // 2,
                440
            )
        )


    # =========================
    # UPDATE SCREEN
    # =========================
    pygame.display.update()

    clock.tick(60)


# =========================
# EXIT
# =========================
pygame.quit()