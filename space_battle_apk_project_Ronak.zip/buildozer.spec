[app]

# (str) Title of your application
title = SPACE BATTLE

# (str) Package name
package.name = spacebattle

# (str) Package domain
package.domain = org.example

# (str) Source code where main.py lives
source.dir = .

# (list) Source files to include
source.include_exts = py

# (str) Application version
version = 1.0

# (list) Python requirements
requirements = python3,pygame

# (str) Portrait Android app
orientation = portrait

# (bool) Fullscreen
fullscreen = 1

# (str) Android app permissions
android.permissions = VIBRATE

# (str) Supported Android architectures
android.archs = arm64-v8a

[buildozer]

# (int) Log level (0 = error only, 1 = info, 2 = debug)
log_level = 2

# (bool) Warn if build directory is not clean
warn_on_root = 1
